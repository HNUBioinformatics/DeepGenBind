"""
# -*- coding: utf-8 -*-
# @Author : Sun JJ
# @File : train.py
# @Time : 2022/7/23 20:54
# code is far away from bugs with the god animal protecting
#         ┌─┐       ┌─┐
#      ┌──┘ ┴───────┘ ┴──┐
#      │                 │
#      │       ───       │
#      │  ─┬┘       └┬─  │
#      │                 │
#      │       ─┴─       │
#      │                 │
#      └───┐         ┌───┘
#          │         │
#          │         │
#          │         │
#          │         └──────────────┐
#          │                        │
#          │                        ├─┐
#          │                        ┌─┘
#          │                        │
#          └─┐  ┐  ┌───────┬──┐  ┌──┘
#            │ ─┤ ─┤       │ ─┤ ─┤
#            └──┴──┘       └──┴──┘
"""

import os

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"

import tensorflow as tf

config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)

from load_data import *
from sklearn import metrics
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, LSTM, BatchNormalization, Activation, Flatten
from tensorflow.keras.layers import Input, concatenate
from keras import backend as K
from keras.callbacks import LearningRateScheduler
from sklearn.metrics import roc_auc_score, accuracy_score, precision_recall_curve, auc
import argparse

parser = argparse.ArgumentParser(description='Parameters to be used for training.')
parser.add_argument('-filename', '--FN', required=True)

args = parser.parse_args()
file_name = args.FN

print('*'*30)
print(file_name)
print('*'*30)


def jiao():
	input_sequence = Input(shape=(101, 12))
	towerA_1 = Conv1D(filters=64, kernel_size=1, padding='same', kernel_initializer='he_normal')(input_sequence)
	towerA_1 = BatchNormalization()(towerA_1)
	towerA_1 = Activation('relu')(towerA_1)
	towerA_2 = Conv1D(filters=128, kernel_size=3, padding='same', kernel_initializer='he_normal')(input_sequence)
	towerA_2 = BatchNormalization()(towerA_2)
	towerA_2 = Activation('relu')(towerA_2)
	towerA_3 = Conv1D(filters=256, kernel_size=5, padding='same', kernel_initializer='he_normal')(input_sequence)
	towerA_3 = BatchNormalization()(towerA_3)
	towerA_3 = Activation('relu')(towerA_3)
	output = concatenate([towerA_1, towerA_2, towerA_3], axis=-1)
	output = MaxPooling1D(pool_size=3, padding='same')(output)
	output = Dropout(rate=0.5)(output)
	
	towerB_1 = Conv1D(filters=128, kernel_size=1, padding='same', kernel_initializer='he_normal')(output)
	towerB_1 = BatchNormalization()(towerB_1)
	towerB_1 = Activation('relu')(towerB_1)
	towerB_2 = Conv1D(filters=256, kernel_size=3, padding='same', kernel_initializer='he_normal')(output)
	towerB_2 = BatchNormalization()(towerB_2)
	towerB_2 = Activation('relu')(towerB_2)
	towerB_3 = Conv1D(filters=512, kernel_size=5, padding='same', kernel_initializer='he_normal')(output)
	towerB_3 = BatchNormalization()(towerB_3)
	towerB_3 = Activation('relu')(towerB_3)
	towerB_4 = Conv1D(filters=1024, kernel_size=7, padding='same', kernel_initializer='he_normal')(output)
	towerB_4 = BatchNormalization()(towerB_4)
	towerB_4 = Activation('relu')(towerB_4)
	output = concatenate([towerB_1, towerB_2, towerB_3, towerB_4], axis=-1)
	output = MaxPooling1D(pool_size=3, padding='same')(output)
	output = Dropout(rate=0.5)(output)
	
	output = Conv1D(filters=64, kernel_size=1, kernel_initializer='he_normal')(output)
	output = BatchNormalization()(output)
	output = Activation('relu')(output)
	
	output = LSTM(units=128, return_sequences=True)(output)
	output = Dropout(rate=0.5)(output)
	output = LSTM(units=256, return_sequences=True)(output)
	output = Dropout(rate=0.5)(output)
	output = Flatten()(output)
	output = Dense(units=1, activation='sigmoid')(output)
	# print(output[:,0] >= 0.5)
	
	model = Model(input_sequence, output)
	
	model.compile(loss='binary_crossentropy',  # binary_crossentropy / categorical_crossentropy
				  optimizer='nadam',
				  metrics=['binary_accuracy'])    # binary_accuracy
	
	return model


def scheduler(epoch):
	# 每隔10个epoch，学习率减小为原来的1/2
	if epoch % 10 == 0 and epoch != 0:
		lr = K.get_value(model.optimizer.lr)
		K.set_value(model.optimizer.lr, lr * 0.5)
		print("lr changed to {}".format(lr * 0.5))
	return K.get_value(model.optimizer.lr)
reduce_lr = LearningRateScheduler(scheduler)

# file_name = 'wgEncodeAwgTfbsBroadHelas3Ezh239875UniPk'
# load data
train_seq, test_seq, train_label, test_label = load_data(file_name)

# print('*'*30)
# print(train_seq.shape)
# print('*'*30)

# load model
model = jiao()

checkpoint_save_path = "./checkpoint/" + file_name + ".ckpt"
if os.path.exists(checkpoint_save_path + '.index'):
	print('-------------load the model-----------------')
	model.load_weights(checkpoint_save_path)
cp_callback = tf.keras.callbacks.ModelCheckpoint(filepath=checkpoint_save_path,
												 save_weights_only=True,
												 save_best_only=True)

history = model.fit(x = train_seq,y = train_label,
                    batch_size = 128,epochs = 30,
                    validation_data = (test_seq,test_label),
                    shuffle = False,callbacks = [cp_callback,reduce_lr])


a = model.predict(test_seq)
c = a.round()

# for i in range(a.shape[0]):
# 	if a[i][0] >= 0.5:
# 		a[i][0] = 1
# 	else:
# 		a[i][0] = 0
# print(a == c)

ACC = accuracy_score(test_label, c)
# print("ACC: {}".format(ACC))

AUC = roc_auc_score(test_label, c)
# print("AUC: {}".format(AUC))

precisions, recalls, _thresholds = precision_recall_curve(test_label, c)
PR_AUC = auc(recalls, precisions)
# print("PR_AUC: {}".format(PR_AUC))

precision = metrics.precision_score(test_label,c)
recall = metrics.recall_score(test_label,c)
f1 = metrics.f1_score(test_label,c)



with open('./result.txt','a') as f:
	f.write('{}: {} {} {} {} {}'.format(file_name,ACC,AUC,precision,recall,f1))
	f.write('\n')