"""
# -*- coding: utf-8 -*-
# @Author : Sun JJ
# @File : load_data.py
# @Time : 2022/7/23 9:06
# code is far away from bugs with the god animal protecting
#         ┌─┐       ┌─┐
#      ┌──┘ ┴───────┘ ┴──┐
#      │                 │
#      │       ───       │
#      │  ─┬┘       └┬─  │
#      │                 │
#      │       ─┴─       │
#      │                 │
#      └───┐         ┌───┘
#          │         │
#          │         │
#          │         │
#          │         └──────────────┐
#          │                        │
#          │                        ├─┐
#          │                        ┌─┘
#          │                        │
#          └─┐  ┐  ┌───────┬──┐  ┌──┘
#            │ ─┤ ─┤       │ ─┤ ─┤
#            └──┴──┘       └──┴──┘
"""



import numpy as np
import pandas as pd



def one_hot(seq):
	
	seq_one_hot = []
	
	for k in seq:
		if k == 'A':
			# seq_one_hot.append(1)
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			seq_one_hot.append([1, 0, 0, 0])
		elif k == 'G':
			# seq_one_hot.append(0)
			# seq_one_hot.append(1)
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			seq_one_hot.append([0, 1, 0, 0])
		elif k == 'C':
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			# seq_one_hot.append(1)
			# seq_one_hot.append(0)
			seq_one_hot.append([0, 0, 1, 0])
		else:
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			# seq_one_hot.append(0)
			# seq_one_hot.append(1)
			seq_one_hot.append([0, 0, 0, 1])
	
	seq_one_hot = np.array(seq_one_hot,dtype = np.int8)
	
	return seq_one_hot


def kmer_1(seq):
	kmer_one_hot = []
	
	for i in range(len(seq)):
		if i == len(seq) - 1:
			_seq = seq[i]
			seq_one_hot = []
			for k in _seq:
				if k == 'A':
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
				# seq_one_hot.append([1, 0, 0, 0])
				elif k == 'G':
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
				# seq_one_hot.append([0, 1, 0, 0])
				elif k == 'C':
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
				# seq_one_hot.append([0, 0, 1, 0])
				else:
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
			for i in range(8):
				seq_one_hot.append(0)
			kmer_one_hot.append(seq_one_hot)
		elif i == len(seq) - 2:
			_seq = seq[i:i+2]
			seq_one_hot = []
			for k in _seq:
				if k == 'A':
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
				# seq_one_hot.append([1, 0, 0, 0])
				elif k == 'G':
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
				# seq_one_hot.append([0, 1, 0, 0])
				elif k == 'C':
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
				# seq_one_hot.append([0, 0, 1, 0])
				else:
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
			for i in range(4):
				seq_one_hot.append(0)
			kmer_one_hot.append(seq_one_hot)
		else:
			_seq = seq[i:i+3]
			seq_one_hot = []
			for k in _seq:
				if k == 'A':
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					# seq_one_hot.append([1, 0, 0, 0])
				elif k == 'G':
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					# seq_one_hot.append([0, 1, 0, 0])
				elif k == 'C':
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					seq_one_hot.append(0)
					# seq_one_hot.append([0, 0, 1, 0])
				else:
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(0)
					seq_one_hot.append(1)
					# seq_one_hot.append([0, 0, 0, 1])
			kmer_one_hot.append(seq_one_hot)
	kmer_one_hot = np.array(kmer_one_hot,dtype = np.int8)
	
	return kmer_one_hot


def kmer(seq,k,s):
	kmer_one_hot = []
	
	for i in range(0,len(seq) - (k - 1),s):
		_seq = seq[i:i + k]
		seq_one_hot = []
		for s in _seq:
			if s == 'A':
				seq_one_hot.append(1)
				seq_one_hot.append(0)
				seq_one_hot.append(0)
				seq_one_hot.append(0)
			# seq_one_hot.append([1, 0, 0, 0])
			elif s == 'G':
				seq_one_hot.append(0)
				seq_one_hot.append(1)
				seq_one_hot.append(0)
				seq_one_hot.append(0)
			# seq_one_hot.append([0, 1, 0, 0])
			elif s == 'C':
				seq_one_hot.append(0)
				seq_one_hot.append(0)
				seq_one_hot.append(1)
				seq_one_hot.append(0)
			# seq_one_hot.append([0, 0, 1, 0])
			else:
				seq_one_hot.append(0)
				seq_one_hot.append(0)
				seq_one_hot.append(0)
				seq_one_hot.append(1)
		# seq_one_hot.append([0, 0, 0, 1])
		kmer_one_hot.append(seq_one_hot)
	kmer_one_hot = np.array(kmer_one_hot, dtype=np.int8)
	
	return kmer_one_hot


def fanbei(seq):
	def reverseString(s):
		s = s[::-1]
		return s
	
	base_complementation = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
	
	re_seq = reverseString(seq)
	
	seq = seq + re_seq
	seq_finall = seq
	
	for i in range(len(seq)):
		seq_finall = seq_finall + base_complementation[seq[i]]
	
	return seq_finall



def load_data(file_name):
	
	test_seq_path = './Data/' + file_name + '/Sequence/Test_seq.csv'
	train_seq_path = './Data/' + file_name + '/Sequence/Train_seq.csv'

	
	
	test_seq_list = []
	test_label_list = []
	test_seq = pd.read_csv(test_seq_path,header = None)
	for i in range(len(test_seq)):
		seq = list(test_seq.iloc[i])[0].split(' ')[1]
		# seq_one_hot = one_hot(seq)
		# seq = fanbei(seq)
		
		seq_one_hot = kmer(seq,3,1)
		
		# seq_one_hot = kmer_1(seq)
		
		label = int(list(test_seq.iloc[i])[0].split(' ')[2])
		test_seq_list.append(seq_one_hot)
		test_label_list.append(label)

	test_seq_np = np.array(test_seq_list,dtype = np.int8)
	test_label_np = np.array(test_label_list,dtype = np.int8)

	train_seq_list = []
	train_label_list = []
	train_seq = pd.read_csv(train_seq_path, header=None)
	for i in range(len(train_seq)):
		seq = list(train_seq.iloc[i])[0].split(' ')[1]
		# seq = fanbei(seq)
		# seq_one_hot = one_hot(seq)
		
		seq_one_hot = kmer(seq,3,1)
		
		# seq_one_hot = kmer_1(seq)
		label = int(list(train_seq.iloc[i])[0].split(' ')[2])
		train_seq_list.append(seq_one_hot)
		train_label_list.append(label)

	train_seq_np = np.array(train_seq_list, dtype=np.int8)
	train_label_np = np.array(train_label_list, dtype=np.int8)



	test_label_np = test_label_np.reshape(test_label_np.shape[0],1)
	train_label_np = train_label_np.reshape(train_label_np.shape[0],1)

	# print(train_shape.shape, test_shape.shape)
	# print(train_seq_np.shape,test_seq_np.shape)
	# print(train_label_np.shape,test_label_np.shape)

	return train_seq_np, test_seq_np, train_label_np, test_label_np
	
# load_data('wgEncodeAwgTfbsBroadDnd41Ezh239875UniPk')